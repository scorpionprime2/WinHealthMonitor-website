WinHealthMonitor 1.4.0
Compact Windows x64 release

LIGHTWEIGHT PACKAGE
This is a framework-dependent package. Install the Microsoft .NET 10 Desktop Runtime for Windows x64 before running WinHealthMonitor.exe. The Desktop Runtime is separate from the .NET SDK.

LIVE TEMPERATURES
The dashboard reads CPU, GPU, and storage-drive temperatures from HWiNFO's shared-memory feed. Keep HWiNFO running and enable Settings > General > Shared Memory Support in HWiNFO; WinHealthMonitor does not probe hardware independently, load a hardware-access driver, or fall back to another sensor source. Cards refresh every 20 seconds, including while the app is minimized to the system tray, and health reports include representative readings captured during their scan. GPU core and hotspot readings are shown separately when available. Generic high-temperature warnings are raised at CPU 90 C, GPU core 85 C, GPU hotspot/junction 100 C, and storage 70 C. New threshold crossings appear in the dashboard and trigger a Windows tray notification; warnings do not shut down the PC. These thresholds are general guidance, not manufacturer-specific limits. Storage devices are identified by their HWiNFO-reported names; HWiNFO may not expose drive letters. The app does not estimate missing temperatures or include them in the health score.

DASHBOARD, HISTORY, AND ACTIVITY
The dashboard shows the latest health score and breakdown, plus a local chart of up to 30 past scores. Health history is stored under %LOCALAPPDATA%\WinHealthMonitor. A task-labeled animated activity bar appears while checks, maintenance actions, and restore-point operations are running.

SYSTEM TRAY AND SINGLE INSTANCE
Only one normal WinHealthMonitor window can run per Windows session. Starting it again brings the existing window forward instead of opening a duplicate. Scheduled and elevated maintenance helper processes continue to work separately. The app adds a custom shield-and-heartbeat icon to the system tray while running. Minimize the window to keep it in the tray. Double-click the icon or choose Open WinHealthMonitor to restore the window; choose Exit to close the app and remove the tray icon. Closing the window exits the app.

HEALTH ANALYSIS AND DRIVES
The app checks memory use, disk capacity, storage Event 129 entries, and disk-related events from the past seven days. It groups duplicate drive aliases and repeated disk-event bursts. The score starts at 100 and subtracts:
- 10 points per Event 129 event, up to 50 points.
- 20 points if memory status cannot be read.
- 15 points per unique volume below 10% free space, up to 30 points.
- 10 points per disk-related incident, up to 40 points, when that scan succeeds.
The final score cannot go below 0. Scores of 80-100 are Healthy, 50-79 are Warning, and 0-49 are Critical. Failed event or disk scans are shown as unavailable and do not deduct points; unavailable memory status does deduct 20 points.

The dashboard and reports list each ready fixed volume by drive letter and Windows-reported filesystem type, with volume label (when available), total capacity, free capacity, and free-space percentage. Drive aliases for the same volume are grouped and counted once.

WEEKLY TASK STATUS AND RESTORE-POINT READINESS
The dashboard displays whether the weekly health scan and restore-point task are scheduled. For restore points it shows the scheduler state, last and next run, and the last task result when available. The Check readiness button checks Windows-drive free space, System Restore policy, and whether VSS shadow storage can be queried. A warning or access-denied result means readiness needs review; it does not prove System Protection is disabled, and a clean check cannot guarantee a restore point will be created.

The weekly health scan is an opt-in per-user task for Sundays at 9:00 AM local time. It runs only while your Windows account is signed in, asks Windows to wake the PC, and saves reports under %LOCALAPPDATA%\WinHealthMonitor\Reports.

Restore-point scheduling is opt-in. It creates a SYSTEM task for Sundays at 8:55 AM local time and requires Windows administrator approval. Restore points are stored on the protected Windows system volume, not on external media, and are not a backup of personal files. The task requests that Windows wake the PC, but firmware and power settings must allow wake timers. Windows can limit how often restore points are created, so check the displayed last task result if a point is missed. Enabling the schedule does not create a restore point immediately.

REPAIRS AND SECURITY
SFC /scannow checks and may repair protected Windows system files. DISM CheckHealth and ScanHealth inspect the online Windows image; DISM RestoreHealth can repair the component store. Every maintenance action requires an in-app confirmation and Windows administrator approval. Timestamped TXT output is saved under %LOCALAPPDATA%\WinHealthMonitor\Repairs and the latest report can be opened from the dashboard. No repair runs automatically.

Routine health checks do not require elevation. WinHealthMonitor never asks for, stores, or transmits your Windows password. Windows handles administrator approval or credentials according to account and system policy. Only fixed Windows maintenance commands are available; arbitrary commands cannot be supplied.

SAFE MODE
Restart to Safe Mode options uses Windows Advanced Startup. Save work first, then choose Troubleshoot > Advanced options > Startup Settings > Restart and press 4/F4 for Safe Mode. The app does not set a persistent boot flag.

Health checks are indicators, not a diagnosis. Back up important data before system repairs.

SIGNING
This package is unsigned. The Windows company metadata is not a digital signature and does not verify the publisher. A valid Authenticode certificate must be used before distributing it as signed software.
